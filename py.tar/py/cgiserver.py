import CGIHTTPServer
CGIHTTPServer.test()
