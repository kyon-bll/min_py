import SimpleHTTPServer
SimpleHTTPServer.test()
